/**
 * NarutoUI's client-side Modern UI configuration-screen library.
 *
 * <p>The public API is grouped by responsibility:
 *
 * <ul>
 *   <li>{@code screen} — configuration screens, fragments, pages and section builders
 *       ({@code MuiSettingsScreen}, {@code MuiConfigScreen}, {@code MuiSettingsPage},
 *       {@code MuiPageContext}, {@code MuiScreenHost}).</li>
 *   <li>{@code widget} — reusable chainable controls and layouts
 *       ({@code MuiControls}, {@code MuiLayout}, {@code MuiCollapsibleCard},
 *       {@code MuiNumberField}, {@code MuiChip}, {@code MuiTextAction},
 *       {@code MuiLogo}, {@code MuiHintBadge}, {@code MuiColorField},
 *       {@code MuiDescriptionRow}, {@code MuiThemePicker}).</li>
 *   <li>{@code theme} — theme tokens and widget factories
 *       ({@code MuiTheme}, {@code MuiWidgetFactory}, {@code MuiShimmerWidgetFactory}).</li>
 *   <li>{@code background} — static, image and slideshow backgrounds, plus the turnkey
 *       configurable background controller.</li>
 *   <li>{@code shimmer} — shimmer profiles, drawing primitives and shimmer-aware widgets.</li>
 *   <li>{@code overlay} — modal color-picker and crop overlays.</li>
 *   <li>{@code util} — localization lookup and native file/folder picking.</li>
 * </ul>
 *
 * <p>Application code usually starts with {@code screen.MuiSettingsScreen} and composes rows with
 * {@code widget.MuiControls} or the higher-level {@code screen.MuiSettingsSection} DSL.
 */
package me.kall.narutoui.mui;