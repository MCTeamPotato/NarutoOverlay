package me.kall.narutoui.mui.widget;

import icyllis.modernui.core.Context;
import icyllis.modernui.graphics.drawable.ShapeDrawable;
import icyllis.modernui.view.Gravity;
import icyllis.modernui.view.View;
import icyllis.modernui.widget.LinearLayout;
import icyllis.modernui.widget.TextView;
import me.kall.narutoui.mui.theme.MuiTheme;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Generic theme-card selector. The caller supplies one {@link Option} per theme; the API builds the
 * tiles, the selected outline, the "in use" label and the click handling.
 */
public final class MuiThemePicker {
    private MuiThemePicker() {}

    /**
     * One selectable theme card: everything the picker needs to draw a tile and to apply a choice.
     * Immutable; build one with {@link #of} and attach a rich preview with {@link #preview(Preview)}.
     *
     * @param title    visible theme name or translation key
     * @param subtitle optional secondary line
     * @param selected whether this option is the current choice
     * @param select   applies the choice; the picker runs it before the {@code changed} callback
     * @param accent   ARGB accent color used by the default preview
     * @param surface  ARGB surface color used by the default preview
     * @param preview  optional rich preview, or {@code null} for the default swatch
     */
    public record Option(
            @NotNull CharSequence title,
            @Nullable CharSequence subtitle,
            boolean selected,
            @NotNull Runnable select,
            int accent,
            int surface,
            @Nullable Preview preview
    ) {
        /**
         * Builds a rich preview for one tile. Attach it with {@link Option#preview(Preview)};
         * options without a preview use the default accent/surface swatch.
         */
        @FunctionalInterface
        public interface Preview {
            /**
             * Builds the preview view.
             *
             * @param context the screen context
             * @param theme   active API theme
             * @return the preview view
             */
            @NotNull View create(@NotNull Context context, @NotNull MuiTheme theme);
        }

        /**
         * Creates an option with the default preview.
         *
         * @param title    visible theme name or translation key
         * @param selected whether this option is the current choice
         * @param select   applies the choice
         * @param accent   ARGB accent color used by the default preview
         * @param surface  ARGB surface color used by the default preview
         * @return the option
         */
        public static @NotNull Option of(@NotNull CharSequence title, boolean selected, @NotNull Runnable select, int accent, int surface) {
            return new Option(title, null, selected, select, accent, surface, null);
        }

        /**
         * Creates an option with a subtitle and the default preview.
         *
         * @param title    visible theme name or translation key
         * @param subtitle optional secondary line
         * @param selected whether this option is the current choice
         * @param select   applies the choice
         * @param accent   ARGB accent color used by the default preview
         * @param surface  ARGB surface color used by the default preview
         * @return the option
         */
        public static @NotNull Option of(@NotNull CharSequence title, @Nullable CharSequence subtitle, boolean selected, @NotNull Runnable select, int accent, int surface) {
            return new Option(title, subtitle, selected, select, accent, surface, null);
        }

        /**
         * Returns a copy with a rich preview.
         *
         * @param preview preview factory
         * @return the new option
         */
        public @NotNull Option preview(@NotNull Preview preview) {
            return new Option(this.title, this.subtitle, this.selected, this.select, this.accent, this.surface, preview);
        }

        /**
         * Builds the custom preview, or returns {@code null} when the default swatch applies.
         *
         * @param context the screen context
         * @param theme   active API theme
         * @return the preview view, or {@code null}
         */
        public @Nullable View previewView(@NotNull Context context, @NotNull MuiTheme theme) {
            return this.preview == null ? null : this.preview.create(context, theme);
        }
    }

    /**
     * Builds a two-column theme picker as a standalone layout using the default {@code "In use"}
     * label.
     *
     * @param context the screen context
     * @param theme   active theme
     * @param options selectable options
     * @param changed callback invoked after an option is selected
     * @return the picker layout
     */
    public static @NotNull MuiLayout create(@NotNull Context context, @NotNull MuiTheme theme, @NotNull List<? extends Option> options, @NotNull Runnable changed) {
        return create(context, theme, options, "In use", changed);
    }

    /**
     * Builds a two-column theme picker as a standalone layout.
     * <p>
     * Inside the settings DSL prefer
     * {@link me.kall.narutoui.mui.screen.MuiSettingsSection#themePicker(List, Runnable)}, which adds
     * the picker as a normal card row. The returned layout is for low-level pages and for embedding
     * through {@link me.kall.narutoui.mui.screen.MuiSettingsSection#custom(icyllis.modernui.view.View)}.
     *
     * @param context the screen context
     * @param theme   active theme
     * @param options selectable options
     * @param inUse   label shown on the selected option
     * @param changed callback invoked after an option is selected
     * @return the picker layout
     */
    public static @NotNull MuiLayout create(@NotNull Context context, @NotNull MuiTheme theme, @NotNull List<? extends Option> options, @NotNull CharSequence inUse, @NotNull Runnable changed) {
        MuiLayout column = MuiLayout.column(context, theme);

        for (int i = 0; i < options.size(); i += 2) {
            MuiLayout row = MuiLayout.row(context, theme).padding(0);

            Option left = options.get(i);
            row.add(tile(context, theme, left, inUse, changed), tileParams(context, i + 1 < options.size()));

            if (i + 1 < options.size()) {
                row.add(tile(context, theme, options.get(i + 1), inUse, changed), tileParams(context, false));
            }

            LinearLayout.LayoutParams params = MuiControls.fill();
            params.topMargin = i == 0 ? 0 : MuiControls.dp(context, 8);
            column.add(row, params);
        }

        return column;
    }

    /**
     * Builds one selectable theme tile.
     *
     * @param context the screen context
     * @param theme   active theme
     * @param option  option model
     * @param inUse   selected label
     * @param changed selection callback
     * @return the tile view
     */
    private static @NotNull View tile(@NotNull Context context, @NotNull MuiTheme theme, @NotNull Option option, @NotNull CharSequence inUse, @NotNull Runnable changed) {
        LinearLayout tile = MuiControls.column(context);
        tile.setPadding(MuiControls.dp(context, 10), MuiControls.dp(context, 10), MuiControls.dp(context, 10), MuiControls.dp(context, 10));

        ShapeDrawable background = new ShapeDrawable();
        background.setCornerRadius(MuiControls.dp(context, theme.cornerRadius()));
        background.setColor(theme.surfaceHigh());
        background.setStroke(Math.max(1, MuiControls.dp(context, 1)), option.selected() ? theme.primary() : theme.outline());
        tile.setBackground(background);

        LinearLayout previewBox = MuiControls.column(context);

        View customPreview = option.previewView(context, theme);
        if (customPreview != null) {
            previewBox.addView(customPreview, MuiControls.fill());
        } else {
            View accent = new View(context);
            ShapeDrawable accentBackground = new ShapeDrawable();
            accentBackground.setCornerRadius(MuiControls.dp(context, 3));
            accentBackground.setColor(option.accent());
            accent.setBackground(accentBackground);
            previewBox.addView(accent, new LinearLayout.LayoutParams(MuiControls.MATCH, MuiControls.dp(context, 8)));

            View body = new View(context);
            ShapeDrawable bodyBackground = new ShapeDrawable();
            bodyBackground.setCornerRadius(MuiControls.dp(context, 5));
            bodyBackground.setColor(option.surface());
            body.setBackground(bodyBackground);
            LinearLayout.LayoutParams bodyParams = new LinearLayout.LayoutParams(MuiControls.MATCH, MuiControls.dp(context, 42));
            bodyParams.topMargin = MuiControls.dp(context, 4);
            previewBox.addView(body, bodyParams);
        }

        tile.addView(previewBox, MuiControls.fill());

        TextView title = MuiControls.text(context, theme, option.title(), 13, option.selected() ? theme.primary() : theme.onSurface());
        LinearLayout.LayoutParams titleParams = MuiControls.fill();
        titleParams.topMargin = MuiControls.dp(context, 8);
        tile.addView(title, titleParams);

        CharSequence subtitle = option.subtitle();
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView subtitleView = MuiControls.text(context, theme, subtitle, 10, theme.onSurfaceVariant());
            tile.addView(subtitleView, MuiControls.fill());
        }

        if (option.selected()) {
            TextView current = MuiControls.text(context, theme, inUse, 10, theme.primary());
            current.setGravity(Gravity.END);
            tile.addView(current, MuiControls.fill());
        }

        tile.setOnClickListener(view -> {
            if (option.selected()) return;
            option.select();
            changed.run();
        });
        return tile;
    }

    /**
     * Returns equal-width layout params for one tile.
     *
     * @param context     the screen context
     * @param trailingGap whether to leave a right gap
     * @return tile layout params
     */
    private static @NotNull LinearLayout.LayoutParams tileParams(@NotNull Context context, boolean trailingGap) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, MuiControls.WRAP, 1.0F);
        if (trailingGap) params.setMargins(0, 0, MuiControls.dp(context, 8), 0);
        return params;
    }
}